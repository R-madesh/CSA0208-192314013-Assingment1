 
#include <stdio.h>

static inline int square(int x)
{
    return x * x;
}

static inline int max_value(int a, int b)
{
    return (a > b) ? a : b;
}

static inline long rupees_to_paise(long rupees)
{
    return rupees * 100L;
}

int main(void)
{
    int i = 5, j = 8;

    printf("Rupees to paise: %ld\n", rupees_to_paise(25));
    printf("Square: %d\n", square(i + 1));
    printf("Maximum: %d\n", max_value(i++, j));
    printf("i after call: %d\n", i);

    return 0;
}
