 
#include <stdio.h>
#include <limits.h>

typedef unsigned short meter_t;

unsigned int consumption(meter_t previous, meter_t current)
{
    return (unsigned short)(current - previous);
}

int main(void)
{
    printf("Data Type Sizes and Limits\n");
    printf("--------------------------\n");

    printf("Size of char       = %zu byte(s)\n", sizeof(char));
    printf("Size of short      = %zu byte(s)\n", sizeof(short));
    printf("Size of int        = %zu byte(s)\n", sizeof(int));
    printf("Size of long       = %zu byte(s)\n", sizeof(long));
    printf("Size of long long  = %zu byte(s)\n", sizeof(long long));
    printf("Size of float      = %zu byte(s)\n", sizeof(float));
    printf("Size of double     = %zu byte(s)\n", sizeof(double));

    printf("\nMeter Information\n");
    printf("Size of meter_t = %zu bytes\n", sizeof(meter_t));
    printf("Maximum reading = %u\n", (unsigned)USHRT_MAX);

    printf("\nConsumption Calculations\n");
    printf("Normal reading: %u units\n",
           consumption(1200, 1530));

    printf("Rollover reading: %u units\n",
           consumption(65400, 120));

    return 0;
}
